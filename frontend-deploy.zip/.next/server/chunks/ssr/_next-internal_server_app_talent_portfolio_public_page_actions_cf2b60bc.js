module.exports=[96418,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_talent_portfolio_public_page_actions_cf2b60bc.js.map