(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/MapView.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_mapbox-gl_dist_mapbox-gl_67f88fda.js",
  "static/chunks/_c09ccee2._.js",
  {
    "path": "static/chunks/node_modules_mapbox-gl_dist_mapbox-gl_9438b0bd.css",
    "included": [
      "[project]/node_modules/mapbox-gl/dist/mapbox-gl.css [app-client] (css)"
    ]
  },
  "static/chunks/components_MapView_tsx_4f0f8019._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/MapView.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);