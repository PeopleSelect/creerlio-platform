module.exports=[68006,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_test-api_page_actions_f848b5bb.js.map