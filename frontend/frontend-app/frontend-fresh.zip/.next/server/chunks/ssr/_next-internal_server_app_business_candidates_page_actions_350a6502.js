module.exports=[66349,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_business_candidates_page_actions_350a6502.js.map