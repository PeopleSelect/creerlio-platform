(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_MapView_tsx_b267b588._.js",
  "static/chunks/_5576dfac._.js",
  "static/chunks/node_modules_973b4fc3._.js"
],
    source: "dynamic"
});
