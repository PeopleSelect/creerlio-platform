module.exports = [
"[project]/.next-internal/server/app/talent/portfolio/editor/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_talent_portfolio_editor_page_actions_8f2c87bb.js.map