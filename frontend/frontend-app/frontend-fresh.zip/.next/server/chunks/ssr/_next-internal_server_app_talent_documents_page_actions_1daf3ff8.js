module.exports=[88368,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_talent_documents_page_actions_1daf3ff8.js.map