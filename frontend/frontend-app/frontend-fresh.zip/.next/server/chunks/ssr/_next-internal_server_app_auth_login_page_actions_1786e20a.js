module.exports=[22565,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_auth_login_page_actions_1786e20a.js.map