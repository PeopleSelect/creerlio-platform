module.exports=[67711,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_master-data-demo_page_actions_609cbc82.js.map