module.exports=[28306,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_talent_applications_%5Bid%5D_page_actions_5b171feb.js.map