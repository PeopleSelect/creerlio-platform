module.exports=[493,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_talent_map_page_actions_020ab098.js.map